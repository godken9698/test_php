<?php

namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class ExampleComponent extends Component
{
    /**
     * Create a new component instance.
     */
    public $leages;
    public $theme_link;

    public function __construct() {
        $this->theme_link = get_theme_file_uri();
        $this->leages = $this->getMatchs();
    }
    public function sage_time_to_minute($seconds){
        $hours = floor($seconds / 3600); 
      
        // Calculate the remaining seconds 
        // into minutes 
        $minutes = floor(($seconds % 3600) / 60);
        return $hours * 60 + $minutes;
    }
    public function getMinuteOfMatch($rs){
        // $now = wp_date('Y-m-d H:i:s');
        $now = strtotime('2024-04-24 17:03:00');
        $match = strtotime($rs['matchTime']) + 45 * 60;
        $match2 = strtotime($rs['matchTime2']);
        if($now > $match2){
            $m = ($this->sage_time_to_minute($now - $match2) + 45) . "'";
        }else if($now > $match && $now < $match2){
            $m = 'Nghỉ giữa hiệp';
        }else{
            $m = $this->sage_time_to_minute($now - strtotime($rs['matchTime'])) . "'";
        }
        return $m;
    }
    public function get_team_by_id($id){
        global $wpdb;
        $sql = 'select name_E , flag from team where teamID = ' . $id;
        $results = $wpdb->get_row( $sql, ARRAY_A );
        return $results;
    }
    public function get_index_leage($leages,$rs){
        $index = -1;
        foreach ($leages as $key => $l) {
            if($l['id'] == $rs['sclassID'] && $l['round'] == $rs['round'] && $l['grouping'] == $rs['grouping']){
                $index = $key;
                break;
            }
        }
        return $index;
    }
    protected function getMatchs()
    {
        global $wpdb;
        // $now = wp_date('Y-m-d H:i:s');
        // get date current. Ex :
        $now = '2024-04-24 17:03:00';
        $sql = 'select s.sclassID,s.round, s.grouping, s.homeTeamID,s.guestTeamID,s.homeScore, s.homeHalfScore, s.matchTime, s.matchTime2, s.guestScore, s.guestHalfScore, s.home_Red, s.home_Yellow, s.guest_Red, s.guest_Yellow, s.homeCorner, s.homeCornerHalf, s.guestCorner, s.guestCornerHalf, scl.name_ES as title, scl.name_E as nameLeage, scl.sclass_pic from schedule as s inner join sclass as scl on s.sclassID = scl.sclassID where s.matchTime < "'.$now.'" and "'.$now.'" < DATE_ADD(s.matchTime2, INTERVAL 45 MINUTE)';
        $results = $wpdb->get_results( $sql, ARRAY_A );
        
        $leages = array();
        foreach ($results as $key => $rs) {
            $index = $this->get_index_leage($leages,$rs);
            if($index === -1){
                $leages[] = array(
                    'id'        => $rs['sclassID'],
                    'image'     => $this->theme_link . '/resources/' . $rs['sclass_pic'],
                    'title'     => $rs['title'],
                    'name'      => $rs['nameLeage'],
                    'round'     => $rs['round'],
                    'grouping'  => $rs['grouping'],
                    'matches'   => array(
                            array(
                            'hour' => date('H:i', strtotime($rs['matchTime'])),
                            'minute_match'  => $this->getMinuteOfMatch($rs),
                            'home_team' => $this->get_team_by_id($rs['homeTeamID']),
                            'guest_team' => $this->get_team_by_id($rs['guestTeamID']),
                            'home_score' => $rs['homeScore'] + $rs['homeHalfScore'],
                            'guest_score' => $rs['guestScore'] + $rs['guestHalfScore'],
                            'home_ht_score' => $rs['home_Red'] + $rs['home_Yellow'],
                            'guest_ht_score' => $rs['guest_Red'] + $rs['guest_Yellow'],
                            'home_corner' => $rs['homeCorner'] + $rs['homeCornerHalf'],
                            'guest_corner' => $rs['guestCorner'] + $rs['guestCornerHalf'],
                        )
                    )
                );
            }else{
                $leages[$index]['matches'][] = array(
                            'hour' => date('H:i', strtotime($rs['matchTime'])),
                            'minute_match'  => $this->getMinuteOfMatch($rs),
                            'home_team' => $this->get_team_by_id($rs['homeTeamID']),
                            'guest_team' => $this->get_team_by_id($rs['guestTeamID']),
                            'home_score' => $rs['homeScore'] + $rs['homeHalfScore'],
                            'guest_score' => $rs['guestScore'] + $rs['guestHalfScore'],
                            'home_ht_score' => $rs['home_Red'] + $rs['home_Yellow'],
                            'guest_ht_score' => $rs['guest_Red'] + $rs['guest_Yellow'],
                            'home_corner' => $rs['homeCorner'] + $rs['homeCornerHalf'],
                            'guest_corner' => $rs['guestCorner'] + $rs['guestCornerHalf'],
                        );
            }
            
        }

        // echo '<pre>';
        // print_r($leages);
        // echo '</pre>';
        // die();
        return $leages;
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.example-component');
    }
}
