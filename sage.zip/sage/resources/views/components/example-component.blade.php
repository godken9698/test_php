<div class="container-fluid">
	<div class="section_result">
		<div class="group-buttons">
			<button type="button" class="btn btn-light font-weight-bold">{{ __('Tất cả', 'sage') }}</button>
			<button type="button" class="btn btn-danger font-weight-bold">{{ __('Trực tiếp', 'sage') }}</button>
			<button type="button" class="btn btn-light font-weight-bold">{{ __('Đã kết thúc', 'sage') }}</button>
			<button type="button" class="btn btn-light font-weight-bold">{{ __('Lịch thi đấu', 'sage') }}</button>
		</div>
		<div class="table-match">
			<table class="table">
			  	<tbody>
			  		@foreach($leages as $k => $leage)
				    	<tr style="background: #ccc;">
				    		<td>
				    			<i class="bi bi-star">
					    			<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star" viewBox="0 0 16 16">
									  <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.56.56 0 0 0-.163-.505L1.71 6.745l4.052-.576a.53.53 0 0 0 .393-.288L8 2.223l1.847 3.658a.53.53 0 0 0 .393.288l4.052.575-2.906 2.77a.56.56 0 0 0-.163.506l.694 3.957-3.686-1.894a.5.5 0 0 0-.461 0z"></path>
									</svg>
					    		</i>
					    	</td>
				    		<td colspan="6"><img src="{{esc_attr_e($leage['image'])}}" width="16" alt="">{{esc_html__($leage['title'])}} : {{esc_html__($leage['name'])}} {{$leage['round'] ? ' - Vòng đấu ' . $leage['round'] : ($leage['grouping'] ? ' - Bảng đấu ' . $leage['grouping'] : '') }}</td>
				    	</tr>
				    	@foreach($leage['matches'] as $km => $match)
				    		<tr>
					    		<td><i class="bi bi-star">
					    			<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star" viewBox="0 0 16 16">
									  <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.56.56 0 0 0-.163-.505L1.71 6.745l4.052-.576a.53.53 0 0 0 .393-.288L8 2.223l1.847 3.658a.53.53 0 0 0 .393.288l4.052.575-2.906 2.77a.56.56 0 0 0-.163.506l.694 3.957-3.686-1.894a.5.5 0 0 0-.461 0z"></path>
									</svg>
					    		</i></td>
					    		<td>{{esc_html__($match['hour'])}}</td>
					    		<td><p class="text-danger">{{$match['minute_match']}}</p></td>
					    		<td><p class="">{{esc_html__($match['home_team']['name_E'])}} <img width="16" src="{{$theme_link . '/resources/' . $match['home_team']['flag']}}" alt=""></p></td>
					    		<td><p class="text-danger font-weight-bold">{{esc_html__($match['home_score'])}} - {{esc_html__($match['guest_score'])}}</p></td>
					    		<td><p class=""><img width="16" src="{{$theme_link . '/resources/' . $match['guest_team']['flag']}}" alt=""> {{esc_html__($match['guest_team']['name_E'])}} </p></td>
					    		<td class="font-weight-bold">{{_('HT','sage')}} {{esc_html__($match['home_ht_score'])}} - {{esc_html__($match['guest_ht_score'])}}

					    			<i class="bi bi-star">
						    			<svg style="display: inline" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrows-angle-contract" viewBox="0 0 16 16">
										  	<path fill-rule="evenodd" d="M.172 15.828a.5.5 0 0 0 .707 0l4.096-4.096V14.5a.5.5 0 1 0 1 0v-3.975a.5.5 0 0 0-.5-.5H1.5a.5.5 0 0 0 0 1h2.768L.172 15.121a.5.5 0 0 0 0 .707M15.828.172a.5.5 0 0 0-.707 0l-4.096 4.096V1.5a.5.5 0 1 0-1 0v3.975a.5.5 0 0 0 .5.5H14.5a.5.5 0 0 0 0-1h-2.768L15.828.879a.5.5 0 0 0 0-.707"></path>
										</svg>

						    		</i>
						    		{{esc_html__($match['home_corner'])}} - {{esc_html__($match['guest_corner'])}}
					    		</td>
			    			</tr>
				    	@endforeach
			    	@endforeach
			  	</tbody>
			</table>
		</div>
	</div>
</div>